const table = document.getElementById('table');

let arr = [[],[],[],[],[],[],[],[]];

for (let i = 0; i < arr.length; i++) {
    let tr=document.createElement('tr')
    for (let j = 0; j < 8; j++) {
        let td = document.createElement('td');
        td.setAttribute('id', `${i}${j}`);
        td.innerHTML = `<input class="inputvalue" maxlength="1" id="inputvalue${i}${j}"  type="text">`;
        // arr[i].push(td);

        // arr[i][j] = td;
        tr.appendChild(td);
    }
    table.appendChild(tr);
// arr.push(tr);
}
console.log(table);