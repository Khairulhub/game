let game_status = true;
let Word = document.getElementById("formmap"); // for make 2d  array


// Create one dimensional array
var gfg = new Array(8);



let array1 = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
let array2 = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];

let player1 = array1;
let player2 = array2;


// console.log('player1',player1);
let player1Array = [];
let player2Array = [];



let newArray = []; // 64 elements inter this array 1d array

let newArray2 = []; // 64 elements inter this array and make 2d array by 8*8


console.log(Word.length);
for(let i=0;i<Word.length;i++){
    newArray.push(Word[i]?.value);
}


// Loop to create 2D array using 1D array
for (var i = 0; i < gfg.length; i++) {
    gfg[i] = [];
}


var h = 0;
var s = newArray.value;


// Loop to initialize 2D array elements.
for (var i = 0; i < 8; i++) {
    for (var j = 0; j < 8; j++) {
  
        gfg[i][j] = s[h++];
    }
    console.log(gfg[i][j]);
}
console.log('gfg',gfg);

// Loop to display the elements of 2D array.
for (var i = 0; i < 8; i++) {
    for (var j = 0; j < 8; j++)
    {
        document.write(gfg[i][j] + " ");
    }
    document.write("<br>");
}

// while(newArray.length>0){
//     newArray2.push(newArray.splice(0,8));
// }
// // console.log(newArray); =============================
// console.log(newArray2);







const wordGame = (number) =>{
    console.log(number);
     let word = document.getElementById("inputvalue"+ number);
     let value = word.value;
        console.log(value);
    //  console.log(word.length);
     word.style.color = game_status ? "black" : "red";
    if(game_status){
         game_status = false;
        //   if((player1.includes(value))&&(word.value)){
        //       player1Array.push(value);
        //       console.log('player1Array',player1Array.includes(value));
        //       if(player1Array!=value){
        //           alert('you have already entered this word');
        //           word.value = '';
        //       }                             
        //       // if(player1Array.length == 26){
        //       //     game_status = false;
        //       //     alert("Player 1 Won");
        //       // }
        //    }
        //    else{
        //       word.value = "";
        //       // word.style.color = "red";
        //   }
     }
    else{
         game_status = true;
        //   if((player2.includes(value))&&(word.value)){
        //       player2Array.push(value);
        //       console.log('player2Array',player2Array.includes(value));
        //       if(player2Array!=value){
        //           alert('you have already entered this word');
        //           word.value = '';
        //       }                             
        //       // if(player1Array.length == 26){
        //       //     game_status = false;
        //       //     alert("Player 1 Won");
        //       // }
        //    }
        //    else{
        //       word.value = "";
        //       // word.style.color = "red";
        //   }
    }

    // for (let i = 0; i < gfg.length; i++) {
    //     // newArray2[i]=newArray2[i].join("");
    //     gfg[i]=[]
    //     for (let j = 0; j < gfg.length; j++) {
            
    //         // console.log(word);
    //         // newArray2[i].push(word.value)
    //         if((document.getElementById("inputvalue"+ number).value !== '')){
    //             gfg[i].push(document.getElementById("inputvalue"+ number).value);
      

    //            //  array = document.getElementById(e.target.id) != '' ? value : '';
                
               
    //             // console.log(arr[i]);
    //            //  if (arr[i][j]==player1 || arr[i][j]==player2) {
    //            //      console.log('winner');
    //            //  }
    //         }
    //         else{
    //             gfg[i].push('');
    //         }
    //     }
        
        
    // }
    // console.log(gfg);


    









//     //  for change the color of the input
//     // if(number %2 == 0){
//     //     word.style.color = "red";
        
//     //     //person2 =========================> by using number
//     //     let newArray2 = player2.iOf(value);
//     //     if(newArray2 > -1){
//     //         player2.splice(newArray2, 1);
//     //         console.log(player2);
//     //     }
//     //     for(let i = 0; i< 1 ; i++){
//     //         player2Array.push(value);
//     //     }
//     //     console.log('player2',player2Array);
        
//     //     if((player2.lenght==26) && (player2Array.lenght==26)){
//     //         word.disabled = true;
//     //     }
//     // }
//     // else{
//     //     word.style.color = "black";
      
//     //     //person1============> by using number

//     //     let newArray1 = player1.iOf(value);
//     //     if(newArray1 > -1){
//     //         player1.splice(newArray1, 1);
//     //         console.log(player1);
//     //     }
        
//     //     for(let i = 0; i< 1 ; i++){
//     //         player1Array.push(value);
//     //     }
//     //     console.log('player1',player1Array);
//     // }
    
    
    
//  // Clone the array for manipulation
//     // var curLetters = value.slice( 0 ), text = "";
//     // console.log(curLetters);



//  // Make sure the word is at least 3 letters long
//     // while ( value.length > 2 ) {
//     //     // Get a word out of the existing letters
//     //      let text = value.join("");
     
//     //     console.log(text);
//     //     // And see if it's in the dictionary
//     //     // if ( dict[ text ] ) {
//     //     //     // If it is, return that word
//     //     //     return text;
//     //     // }
 
//     //     // // Otherwise remove another letter from the end
//     //     // curLetters.pop();
//     // }

   
   
 }




































// ========================>  for dont work to go to back or cut the word
//===> https://stackoverflow.com/questions/664631/disable-backspace-and-delete-key-with-javascript-in-ie

window.onkeydown = function (event) {

    if (event.which == 8) { 

         event.preventDefault();   // turn off browser transition to the previous page 

                 // put here code you need 

        }; 

};